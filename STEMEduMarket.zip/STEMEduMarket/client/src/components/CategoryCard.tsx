import { Link } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { FlaskRound, Laptop, Cog, Calculator } from 'lucide-react';

interface CategoryCardProps {
  icon: string;
  title: string;
  description: string;
  color: string;
  href: string;
}

const CategoryCard = ({ icon, title, description, color, href }: CategoryCardProps) => {
  const getIcon = () => {
    switch (icon) {
      case 'flask':
        return <FlaskRound className={`text-2xl ${color}`} />;
      case 'laptop':
        return <Laptop className={`text-2xl ${color}`} />;
      case 'cog':
        return <Cog className={`text-2xl ${color}`} />;
      case 'calculator':
        return <Calculator className={`text-2xl ${color}`} />;
      default:
        return <FlaskRound className={`text-2xl ${color}`} />;
    }
  };

  const getBgColor = () => {
    switch (color) {
      case 'text-secondary-600':
        return 'bg-secondary-100';
      case 'text-primary-600':
        return 'bg-primary-100';
      case 'text-green-600':
        return 'bg-green-100';
      case 'text-yellow-600':
        return 'bg-yellow-100';
      default:
        return 'bg-slate-100';
    }
  };

  return (
    <Link href={href}>
      <Card className="flex flex-col items-center bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow cursor-pointer">
        <div className={`w-16 h-16 flex items-center justify-center ${getBgColor()} rounded-full mb-4`}>
          {getIcon()}
        </div>
        <h3 className="font-bold text-lg text-slate-800 mb-2">{title}</h3>
        <p className="text-slate-600 text-sm text-center">{description}</p>
      </Card>
    </Link>
  );
};

export default CategoryCard;
