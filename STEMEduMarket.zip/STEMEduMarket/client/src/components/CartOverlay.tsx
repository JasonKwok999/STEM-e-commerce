import { useEffect, useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useCartStore } from '@/lib/cart';
import { Course } from '@/types';
import { useAuth } from '@/hooks/useAuth';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Separator } from '@/components/ui/separator';
import { useQuery } from '@tanstack/react-query';

interface CartOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

const CartOverlay = ({ isOpen, onClose }: CartOverlayProps) => {
  const { items, totalPrice, removeItem, updateQuantity, clearCart } = useCartStore();
  const { user } = useAuth();
  const [, navigate] = useLocation();

  // Load course details for each item in the cart
  const { data: courses } = useQuery({
    queryKey: ['/api/courses'],
    enabled: items.length > 0,
  });

  // Merge cart items with course details
  const cartItemsWithDetails = items.map(item => {
    const course = courses?.find((c: Course) => c.id === item.courseId) || item.course;
    return {
      ...item,
      course
    };
  });

  const proceedToCheckout = () => {
    if (!user) {
      // Redirect to login if user is not authenticated
      navigate('/login?redirect=checkout');
    } else {
      navigate('/checkout');
    }
    onClose();
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-md overflow-auto">
        <SheetHeader>
          <SheetTitle className="text-xl">Shopping Cart ({items.length})</SheetTitle>
        </SheetHeader>
        
        <div className="mt-6 flex flex-col h-full">
          <div className="flex-grow overflow-y-auto space-y-4">
            {cartItemsWithDetails.length === 0 ? (
              <div className="text-center py-10">
                <p className="text-slate-500">Your cart is empty</p>
                <Button variant="outline" className="mt-4" onClick={onClose}>
                  Browse Courses
                </Button>
              </div>
            ) : (
              cartItemsWithDetails.map(item => (
                <div key={item.courseId} className="flex items-center space-x-4 border-b border-slate-200 pb-4">
                  {item.course?.image && (
                    <img 
                      src={item.course.image} 
                      alt={item.course.title} 
                      className="w-16 h-16 object-cover rounded-md"
                    />
                  )}
                  <div className="flex-grow">
                    <h3 className="font-medium text-slate-800">
                      {item.course?.title || `Course #${item.courseId}`}
                    </h3>
                    <p className="text-slate-500 text-sm">
                      {item.course?.instructor || 'Unknown Instructor'}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-slate-800">
                      ${item.course?.price ? (item.course.price * item.quantity).toFixed(2) : 'N/A'}
                    </p>
                    <button 
                      className="text-red-500 text-sm hover:text-red-700"
                      onClick={() => removeItem(item.courseId)}
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
          
          {cartItemsWithDetails.length > 0 && (
            <div className="mt-auto pt-4">
              <Separator className="my-4" />
              <div className="flex justify-between mb-4">
                <span className="font-medium text-slate-600">Subtotal:</span>
                <span className="font-bold text-slate-800">${totalPrice.toFixed(2)}</span>
              </div>
              <Button className="w-full" onClick={proceedToCheckout}>
                Proceed to Checkout
              </Button>
              <Button variant="ghost" className="w-full mt-2" onClick={onClose}>
                Continue Shopping
              </Button>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default CartOverlay;
