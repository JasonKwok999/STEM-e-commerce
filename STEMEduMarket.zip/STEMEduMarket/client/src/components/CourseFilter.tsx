import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { 
  Accordion, 
  AccordionContent, 
  AccordionItem, 
  AccordionTrigger 
} from '@/components/ui/accordion';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';

interface CategoryCount {
  name: string;
  count: number;
}

interface FilterProps {
  categories: CategoryCount[];
  onFilterChange: (filters: any) => void;
}

const CourseFilter = ({ categories, onFilterChange }: FilterProps) => {
  const [location, setLocation] = useLocation();
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<string>('all');
  const [duration, setDuration] = useState<string[]>([]);
  const [rating, setRating] = useState<string>('');

  // Parse query parameters
  useEffect(() => {
    const params = new URLSearchParams(location.split('?')[1]);
    
    // Extract category from URL if present
    const categoryParam = params.get('category');
    if (categoryParam && !selectedCategories.includes(categoryParam)) {
      setSelectedCategories([...selectedCategories, categoryParam]);
    }
  }, [location]);

  const handleCategoryChange = (category: string, checked: boolean) => {
    if (checked) {
      setSelectedCategories([...selectedCategories, category]);
    } else {
      setSelectedCategories(selectedCategories.filter(c => c !== category));
    }
  };

  const handleDurationChange = (duration: string, checked: boolean) => {
    if (checked) {
      setDuration([...duration, duration]);
    } else {
      setDuration(duration.filter(d => d !== duration));
    }
  };

  const applyFilters = () => {
    onFilterChange({
      categories: selectedCategories,
      priceRange,
      duration,
      rating
    });
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-md border border-slate-200">
      <h3 className="font-semibold text-lg mb-4 text-slate-800">Filter Courses</h3>
      
      <Accordion type="multiple" defaultValue={['categories', 'price', 'duration', 'rating']}>
        {/* Category Filter */}
        <AccordionItem value="categories">
          <AccordionTrigger className="font-medium text-slate-700">Categories</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {categories.map(category => (
                <div key={category.name} className="flex items-center space-x-2">
                  <Checkbox 
                    id={`category-${category.name}`} 
                    checked={selectedCategories.includes(category.name)}
                    onCheckedChange={(checked) => handleCategoryChange(category.name, checked as boolean)}
                  />
                  <Label 
                    htmlFor={`category-${category.name}`}
                    className="text-slate-600"
                  >
                    {category.name} ({category.count})
                  </Label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
        
        {/* Price Range */}
        <AccordionItem value="price">
          <AccordionTrigger className="font-medium text-slate-700">Price Range</AccordionTrigger>
          <AccordionContent>
            <RadioGroup value={priceRange} onValueChange={setPriceRange}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="all" id="price-all" />
                <Label htmlFor="price-all" className="text-slate-600">All Prices</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="under50" id="price-under50" />
                <Label htmlFor="price-under50" className="text-slate-600">Under $50</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="50to100" id="price-50to100" />
                <Label htmlFor="price-50to100" className="text-slate-600">$50 - $100</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="100to200" id="price-100to200" />
                <Label htmlFor="price-100to200" className="text-slate-600">$100 - $200</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="over200" id="price-over200" />
                <Label htmlFor="price-over200" className="text-slate-600">$200+</Label>
              </div>
            </RadioGroup>
          </AccordionContent>
        </AccordionItem>
        
        {/* Duration */}
        <AccordionItem value="duration">
          <AccordionTrigger className="font-medium text-slate-700">Duration</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="duration-short" 
                  checked={duration.includes('short')}
                  onCheckedChange={(checked) => handleDurationChange('short', checked as boolean)}
                />
                <Label htmlFor="duration-short" className="text-slate-600">0-4 weeks</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="duration-medium" 
                  checked={duration.includes('medium')}
                  onCheckedChange={(checked) => handleDurationChange('medium', checked as boolean)}
                />
                <Label htmlFor="duration-medium" className="text-slate-600">5-8 weeks</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="duration-long" 
                  checked={duration.includes('long')}
                  onCheckedChange={(checked) => handleDurationChange('long', checked as boolean)}
                />
                <Label htmlFor="duration-long" className="text-slate-600">9-12 weeks</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="duration-extended" 
                  checked={duration.includes('extended')}
                  onCheckedChange={(checked) => handleDurationChange('extended', checked as boolean)}
                />
                <Label htmlFor="duration-extended" className="text-slate-600">12+ weeks</Label>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
        
        {/* Rating */}
        <AccordionItem value="rating">
          <AccordionTrigger className="font-medium text-slate-700">Rating</AccordionTrigger>
          <AccordionContent>
            <RadioGroup value={rating} onValueChange={setRating}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="5" id="rating-5" />
                <Label htmlFor="rating-5" className="text-slate-600 flex items-center">
                  ★★★★★ <span className="ml-1">& up</span>
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="4" id="rating-4" />
                <Label htmlFor="rating-4" className="text-slate-600 flex items-center">
                  ★★★★☆ <span className="ml-1">& up</span>
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="3" id="rating-3" />
                <Label htmlFor="rating-3" className="text-slate-600 flex items-center">
                  ★★★☆☆ <span className="ml-1">& up</span>
                </Label>
              </div>
            </RadioGroup>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
      
      <Button className="w-full mt-6" onClick={applyFilters}>
        Apply Filters
      </Button>
    </div>
  );
};

export default CourseFilter;
