import { Link } from 'wouter';
import { BeakerIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

const Footer = () => {
  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    // This would be connected to a newsletter service in production
  };

  return (
    <footer className="bg-slate-900 text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <BeakerIcon className="h-8 w-8 text-primary" />
              <h3 className="text-xl font-bold">STEM Academy</h3>
            </div>
            <p className="text-slate-400 mb-4">
              Empowering the next generation through quality STEM education that inspires curiosity and builds essential skills.
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white">
                <Facebook size={20} />
              </Button>
              <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white">
                <Twitter size={20} />
              </Button>
              <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white">
                <Instagram size={20} />
              </Button>
              <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white">
                <Youtube size={20} />
              </Button>
            </div>
          </div>
          
          <div>
            <h4 className="font-bold text-lg mb-4">Explore</h4>
            <ul className="space-y-2">
              <li><Link href="/courses" className="text-slate-400 hover:text-white">All Courses</Link></li>
              <li><Link href="/courses?category=Science" className="text-slate-400 hover:text-white">Science</Link></li>
              <li><Link href="/courses?category=Technology" className="text-slate-400 hover:text-white">Technology</Link></li>
              <li><Link href="/courses?category=Engineering" className="text-slate-400 hover:text-white">Engineering</Link></li>
              <li><Link href="/courses?category=Mathematics" className="text-slate-400 hover:text-white">Mathematics</Link></li>
              <li><Link href="/offers" className="text-slate-400 hover:text-white">Special Offers</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold text-lg mb-4">Information</h4>
            <ul className="space-y-2">
              <li><Link href="/about" className="text-slate-400 hover:text-white">About Us</Link></li>
              <li><Link href="/instructors" className="text-slate-400 hover:text-white">Our Instructors</Link></li>
              <li><Link href="/testimonials" className="text-slate-400 hover:text-white">Testimonials</Link></li>
              <li><Link href="/blog" className="text-slate-400 hover:text-white">Blog</Link></li>
              <li><Link href="/careers" className="text-slate-400 hover:text-white">Careers</Link></li>
              <li><Link href="/contact" className="text-slate-400 hover:text-white">Contact Us</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold text-lg mb-4">Support</h4>
            <ul className="space-y-2">
              <li><Link href="/help" className="text-slate-400 hover:text-white">Help Center</Link></li>
              <li><Link href="/faq" className="text-slate-400 hover:text-white">FAQs</Link></li>
              <li><Link href="/terms" className="text-slate-400 hover:text-white">Terms of Service</Link></li>
              <li><Link href="/privacy" className="text-slate-400 hover:text-white">Privacy Policy</Link></li>
              <li><Link href="/refund" className="text-slate-400 hover:text-white">Refund Policy</Link></li>
              <li><Link href="/accessibility" className="text-slate-400 hover:text-white">Accessibility</Link></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-slate-800 pt-6 mt-6 text-center text-slate-500 text-sm">
          <p>&copy; {new Date().getFullYear()} STEM Academy. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
