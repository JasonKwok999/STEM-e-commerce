import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/hooks/useAuth';
import { 
  LayoutDashboard, 
  BookOpen, 
  BarChart, 
  Users, 
  Settings, 
  LogOut,
  Menu
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { 
  Sheet,
  SheetContent,
  SheetTrigger
} from '@/components/ui/sheet';

interface AdminLayoutProps {
  children: React.ReactNode;
}

const AdminLayout = ({ children }: AdminLayoutProps) => {
  const [location] = useLocation();
  const { logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { href: '/admin', icon: <LayoutDashboard className="mr-2 h-5 w-5" />, label: 'Dashboard' },
    { href: '/admin/courses', icon: <BookOpen className="mr-2 h-5 w-5" />, label: 'Courses' },
    { href: '/admin/analytics', icon: <BarChart className="mr-2 h-5 w-5" />, label: 'Analytics' },
    { href: '/admin/users', icon: <Users className="mr-2 h-5 w-5" />, label: 'Users' },
    { href: '/admin/settings', icon: <Settings className="mr-2 h-5 w-5" />, label: 'Settings' }
  ];

  const isActive = (path: string) => {
    return location === path;
  };

  const NavLink = ({ href, icon, label }: { href: string; icon: React.ReactNode; label: string }) => (
    <Link href={href}>
      <Button
        variant={isActive(href) ? "default" : "ghost"}
        className={`w-full justify-start ${isActive(href) ? "bg-primary" : ""}`}
      >
        {icon}
        {label}
      </Button>
    </Link>
  );

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Mobile header */}
      <div className="bg-white border-b md:hidden p-4 flex justify-between items-center sticky top-0 z-20">
        <h1 className="font-bold text-xl text-primary">Admin Dashboard</h1>
        <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon">
              <Menu className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left">
            <div className="mt-6 flex flex-col space-y-2">
              {navLinks.map((link) => (
                <NavLink
                  key={link.href}
                  href={link.href}
                  icon={link.icon}
                  label={link.label}
                />
              ))}
              <Button variant="ghost" className="w-full justify-start" onClick={logout}>
                <LogOut className="mr-2 h-5 w-5" />
                Logout
              </Button>
            </div>
          </SheetContent>
        </Sheet>
      </div>
      
      <div className="flex flex-col md:flex-row">
        {/* Sidebar */}
        <aside className="hidden md:flex flex-col w-64 bg-white shadow-sm h-screen sticky top-0 overflow-y-auto">
          <div className="p-6">
            <h1 className="text-2xl font-bold text-primary">Admin Dashboard</h1>
          </div>
          <nav className="px-4 pb-6 flex-1">
            <div className="space-y-2">
              {navLinks.map((link) => (
                <NavLink
                  key={link.href}
                  href={link.href}
                  icon={link.icon}
                  label={link.label}
                />
              ))}
            </div>
            <div className="absolute bottom-0 left-0 right-0 p-4">
              <Button variant="ghost" className="w-full justify-start text-red-500" onClick={logout}>
                <LogOut className="mr-2 h-5 w-5" />
                Logout
              </Button>
            </div>
          </nav>
        </aside>

        {/* Main content */}
        <main className="flex-1 p-6 md:p-8 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
