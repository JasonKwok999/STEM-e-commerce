import { Course } from '@/types';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useCartStore } from '@/lib/cart';
import { Star, Clock, User } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Link } from 'wouter';

interface CourseCardProps {
  course: Course;
}

const CourseCard = ({ course }: CourseCardProps) => {
  const { addItem } = useCartStore();
  const { toast } = useToast();

  const handleAddToCart = () => {
    addItem(course);
    toast({
      title: "Added to cart",
      description: `${course.title} has been added to your cart.`,
    });
  };

  return (
    <Card className="bg-white rounded-xl shadow-md overflow-hidden transition-transform hover:scale-[1.02] hover:shadow-lg border border-slate-200">
      <div className="relative">
        <Link href={`/courses/${course.id}`}>
          <img 
            src={course.image} 
            alt={course.title} 
            className="w-full h-48 object-cover cursor-pointer"
          />
        </Link>
        {course.bestseller && (
          <span className="absolute top-3 right-3 bg-primary text-white text-sm font-semibold px-3 py-1 rounded-full">
            Bestseller
          </span>
        )}
        {course.isNew && (
          <span className="absolute top-3 right-3 bg-green-600 text-white text-sm font-semibold px-3 py-1 rounded-full">
            New
          </span>
        )}
      </div>
      <CardContent className="p-5">
        <div className="flex justify-between items-start mb-2">
          <Badge variant="secondary" className="bg-secondary-100 text-secondary-800 hover:bg-secondary-200">
            {course.category}
          </Badge>
          <div className="flex items-center">
            <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
            <span className="ml-1 text-sm font-medium text-slate-700">{course.rating.toFixed(1)}</span>
          </div>
        </div>
        <Link href={`/courses/${course.id}`}>
          <h3 className="font-bold text-lg mb-2 text-slate-800 hover:text-primary cursor-pointer">
            {course.title}
          </h3>
        </Link>
        <p className="text-slate-600 text-sm mb-3">{course.description}</p>
        <div className="flex items-center text-sm text-slate-500 mb-4">
          <Clock className="h-4 w-4 mr-1" /> {course.duration}
          <span className="mx-2">•</span>
          <User className="h-4 w-4 mr-1" /> {course.instructor}
        </div>
      </CardContent>
      <CardFooter className="px-5 pb-5 pt-0 flex justify-between items-center">
        <span className="text-lg font-bold text-slate-800">${course.price.toFixed(2)}</span>
        <Button 
          size="sm"
          onClick={handleAddToCart}
        >
          Add to Cart
        </Button>
      </CardFooter>
    </Card>
  );
};

export default CourseCard;
