import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/hooks/useAuth';
import { useCartStore } from '@/lib/cart';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { UserCircle, ShoppingCart, Search, Menu, BeakerIcon } from 'lucide-react';
import CartOverlay from './CartOverlay';

const Header = () => {
  const [location, setLocation] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [cartOpen, setCartOpen] = useState(false);
  
  const { user, isAdmin, isAuthenticated, logout } = useAuth();
  const { totalItems } = useCartStore();
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setLocation(`/courses?search=${searchQuery}`);
  };
  
  return (
    <header className="sticky top-0 z-50 bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <BeakerIcon className="h-8 w-8 text-primary" />
            <h1 className="text-xl font-bold text-primary">STEM Academy</h1>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:block">
            <ul className="flex space-x-8">
              <li>
                <Link href="/" className="font-medium text-slate-700 hover:text-primary transition">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/courses" className="font-medium text-slate-700 hover:text-primary transition">
                  Courses
                </Link>
              </li>
              <li>
                <Link href="/about" className="font-medium text-slate-700 hover:text-primary transition">
                  About
                </Link>
              </li>
              <li>
                <Link href="/contact" className="font-medium text-slate-700 hover:text-primary transition">
                  Contact
                </Link>
              </li>
            </ul>
          </nav>

          {/* Search and User Actions */}
          <div className="flex items-center space-x-4">
            <form onSubmit={handleSearch} className="hidden md:block relative">
              <Input
                type="text"
                placeholder="Search courses..."
                className="w-64 pl-10 pr-4 py-2"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
            </form>
            
            <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setLocation('/search')}>
              <Search className="h-5 w-5" />
            </Button>
            
            <Button
              variant="ghost" 
              size="icon"
              className="relative"
              onClick={() => setCartOpen(true)}
            >
              <ShoppingCart className="h-5 w-5" />
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-primary text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </Button>
            
            {isAuthenticated ? (
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <UserCircle className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent>
                  <SheetHeader>
                    <SheetTitle>My Account</SheetTitle>
                    <SheetDescription>
                      Logged in as {user?.username}
                    </SheetDescription>
                  </SheetHeader>
                  <div className="py-4 space-y-2">
                    {isAdmin && (
                      <Button variant="secondary" className="w-full justify-start" onClick={() => setLocation('/admin')}>
                        Admin Dashboard
                      </Button>
                    )}
                    <Button variant="secondary" className="w-full justify-start" onClick={() => setLocation('/orders')}>
                      My Orders
                    </Button>
                    <Button variant="secondary" className="w-full justify-start" onClick={() => setLocation('/profile')}>
                      Profile Settings
                    </Button>
                    <Button variant="secondary" className="w-full justify-start" onClick={logout}>
                      Logout
                    </Button>
                  </div>
                </SheetContent>
              </Sheet>
            ) : (
              <Button variant="ghost" size="icon" onClick={() => setLocation('/login')}>
                <UserCircle className="h-5 w-5" />
              </Button>
            )}
            
            <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-slate-200 py-4 px-4">
          <form onSubmit={handleSearch} className="mb-4 relative">
            <Input
              type="text"
              placeholder="Search courses..."
              className="w-full pl-10 pr-4 py-2"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
          </form>
          <ul className="space-y-3">
            <li>
              <Link href="/" className="block font-medium text-slate-700" onClick={() => setMobileMenuOpen(false)}>
                Home
              </Link>
            </li>
            <li>
              <Link href="/courses" className="block font-medium text-slate-700" onClick={() => setMobileMenuOpen(false)}>
                Courses
              </Link>
            </li>
            <li>
              <Link href="/about" className="block font-medium text-slate-700" onClick={() => setMobileMenuOpen(false)}>
                About
              </Link>
            </li>
            <li>
              <Link href="/contact" className="block font-medium text-slate-700" onClick={() => setMobileMenuOpen(false)}>
                Contact
              </Link>
            </li>
          </ul>
        </div>
      )}
      
      {/* Cart Overlay */}
      <CartOverlay isOpen={cartOpen} onClose={() => setCartOpen(false)} />
    </header>
  );
};

export default Header;
