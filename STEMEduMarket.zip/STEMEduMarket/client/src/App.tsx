import { Switch, Route } from "wouter";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Home from "@/pages/Home";
import Courses from "@/pages/Courses";
import CourseDetail from "@/pages/CourseDetail";
import Cart from "@/pages/Cart";
import Checkout from "@/pages/Checkout";
import CheckoutSuccess from "@/pages/CheckoutSuccess";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import NotFound from "@/pages/not-found";
import AdminDashboard from "@/pages/Admin/Dashboard";
import AdminCourseManagement from "@/pages/Admin/CourseManagement";
import AdminAnalytics from "@/pages/Admin/Analytics";
import AdminLayout from "@/components/AdminLayout";
import { useAuth } from "./hooks/useAuth";
import { useEffect } from "react";

function ProtectedAdminRoute({ component: Component }: { component: React.ComponentType }) {
  const { isAuthenticated, isAdmin, user } = useAuth();
  
  if (!isAuthenticated) {
    return <Login />;
  }
  
  if (!isAdmin) {
    return <NotFound />;
  }
  
  return <Component />;
}

function App() {
  const { user } = useAuth();
  
  // Sync cart with server when user logs in
  useEffect(() => {
    // This would be where you'd sync the cart with the server
    // if needed when a user logs in
  }, [user]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/courses" component={Courses} />
          <Route path="/courses/:id" component={CourseDetail} />
          <Route path="/cart" component={Cart} />
          <Route path="/checkout" component={Checkout} />
          <Route path="/checkout/success" component={CheckoutSuccess} />
          <Route path="/login" component={Login} />
          <Route path="/register" component={Register} />
          
          {/* Admin Routes */}
          <Route path="/admin">
            {() => (
              <AdminLayout>
                <ProtectedAdminRoute component={AdminDashboard} />
              </AdminLayout>
            )}
          </Route>
          <Route path="/admin/courses">
            {() => (
              <AdminLayout>
                <ProtectedAdminRoute component={AdminCourseManagement} />
              </AdminLayout>
            )}
          </Route>
          <Route path="/admin/analytics">
            {() => (
              <AdminLayout>
                <ProtectedAdminRoute component={AdminAnalytics} />
              </AdminLayout>
            )}
          </Route>
          
          {/* Fallback */}
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

export default App;
