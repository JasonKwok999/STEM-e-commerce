import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useCartStore } from '@/lib/cart';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Loader, CheckCircle, ArrowLeft, AlertCircle } from 'lucide-react';

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  console.warn('Missing VITE_STRIPE_PUBLIC_KEY environment variable. Using test key for development.');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY || 'pk_test_dummy');

const CheckoutForm = () => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentError, setPaymentError] = useState<string | null>(null);
  const [, navigate] = useLocation();
  const { items, totalPrice, clearCart } = useCartStore();
  const { user } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      setPaymentError("Stripe is not initialized. Please refresh the page and try again.");
      return;
    }
    
    // Allow guest checkout for testing
    if (!user) {
      console.log("Proceeding with guest checkout");
    }

    setIsProcessing(true);
    setPaymentError(null);

    try {
      // Get billing details from form
      const billingDetails = {
        name: (document.getElementById('name') as HTMLInputElement)?.value || '',
        email: (document.getElementById('email') as HTMLInputElement)?.value || '',
        address: {
          line1: (document.getElementById('address') as HTMLInputElement)?.value || '',
          city: (document.getElementById('city') as HTMLInputElement)?.value || '',
          state: (document.getElementById('state') as HTMLInputElement)?.value || '',
          postal_code: (document.getElementById('zip') as HTMLInputElement)?.value || '',
        }
      };
      
      console.log('Processing payment with billing details:', { 
        name: billingDetails.name, 
        email: billingDetails.email 
      });
      
      // First, submit the elements to validate them
      try {
        const { error: submitError } = await elements.submit();
        
        if (submitError) {
          setPaymentError(submitError.message || "Form validation failed");
          return;
        }
      } catch (submitError: any) {
        console.error("Element submission error:", submitError);
        setPaymentError(submitError.message || "There was an error validating your payment information");
        return;
      }
      
      // Now confirm the payment with Stripe API
      const confirmResult = await stripe.confirmPayment({
        elements,
        redirect: 'if_required',
        confirmParams: {
          return_url: window.location.origin + '/checkout/success',
          payment_method_data: {
            billing_details: billingDetails
          }
        }
      });
      
      // Handle the confirmation result
      if (confirmResult.error) {
        setPaymentError(confirmResult.error.message || "Payment confirmation failed");
        return;
      } 
      
      // Check payment status
      if (confirmResult.paymentIntent && confirmResult.paymentIntent.status === "succeeded") {
        // Payment successful - create order and clear cart
        await apiRequest("POST", "/api/orders", { 
          userId: user ? user.id : 0, // Use 0 for guest users
          courses: items,
          totalAmount: totalPrice,
          status: 'completed',
          paymentIntentId: confirmResult.paymentIntent.id
        });
        
        clearCart();
        toast({
          title: "Payment Successful",
          description: "Thank you for your purchase!",
        });
        navigate('/checkout/success');
      } else {
        // In case payment requires additional actions (3D Secure, etc)
        toast({
          title: "Processing Payment",
          description: "Your payment is being processed. Please do not close this window.",
        });
      }
    } catch (error) {
      console.error("Error during payment submission:", error);
      setPaymentError("An unexpected error occurred. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {paymentError && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md flex items-start space-x-2">
          <AlertCircle className="h-5 w-5 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="font-medium">Payment Error</h4>
            <p className="text-sm">{paymentError}</p>
          </div>
        </div>
      )}
      
      <div className="space-y-4">
        <h3 className="text-lg font-medium">Billing Information</h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="name">Name</Label>
            <Input id="name" placeholder="John Doe" required />
          </div>
          <div>
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" placeholder="john@example.com" defaultValue={user?.email || ''} required />
          </div>
        </div>
        
        <div>
          <Label htmlFor="address">Address</Label>
          <Input id="address" placeholder="1234 Main St" required />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="city">City</Label>
            <Input id="city" placeholder="New York" required />
          </div>
          <div>
            <Label htmlFor="state">State</Label>
            <Input id="state" placeholder="NY" required />
          </div>
          <div>
            <Label htmlFor="zip">Zip</Label>
            <Input id="zip" placeholder="10001" required />
          </div>
        </div>
      </div>

      <Separator />
      
      <div className="space-y-4">
        <h3 className="text-lg font-medium">Payment Details</h3>
        <PaymentElement />
        <div className="text-xs text-slate-500">
          For testing, use card number: 4242 4242 4242 4242, any future expiration date, any CVC code, and any ZIP code.
        </div>
      </div>

      <Button 
        type="submit" 
        className="w-full" 
        size="lg"
        disabled={!stripe || isProcessing}
      >
        {isProcessing ? (
          <>
            <Loader className="h-4 w-4 animate-spin mr-2" />
            Processing...
          </>
        ) : (
          `Pay $${totalPrice.toFixed(2)}`
        )}
      </Button>
    </form>
  );
};

const CheckoutPage = () => {
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const { items, totalPrice } = useCartStore();
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  useEffect(() => {
    // Redirect if cart is empty
    if (items.length === 0) {
      navigate('/cart');
      return;
    }
    
    // For testing purposes, we'll allow checkout without authentication
    // In a production environment, you would want to require authentication
    if (!isAuthenticated) {
      console.log("User not authenticated, but allowing checkout for testing");
      // We'll still show a toast but not redirect
      toast({
        title: "Guest Checkout",
        description: "You are checking out as a guest. In a production environment, you would need to log in.",
      });
    }
    
    // Create PaymentIntent as soon as the page loads
    const createIntent = async () => {
      try {
        const res = await apiRequest("POST", "/api/create-payment-intent", { 
          amount: totalPrice,
          items: items
        });
        const data = await res.json();
        setClientSecret(data.clientSecret);
      } catch (error) {
        console.error("Error creating payment intent:", error);
        toast({
          title: "Payment Setup Failed",
          description: "There was a problem setting up the payment. Please try again.",
          variant: "destructive",
        });
      }
    };
    
    createIntent();
  }, [items, totalPrice, isAuthenticated, user, navigate, toast]);

  useEffect(() => {
    document.title = 'Checkout | STEM Academy';
    return () => {
      document.title = 'STEM Academy';
    };
  }, []);

  return (
    <div className="container mx-auto px-4 py-12">
      <Button variant="ghost" className="mb-6" onClick={() => navigate('/cart')}>
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Cart
      </Button>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Checkout</CardTitle>
            </CardHeader>
            <CardContent>
              {!clientSecret ? (
                <div className="flex justify-center items-center py-12">
                  <Loader className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : (
                <Elements stripe={stripePromise} options={{ clientSecret }}>
                  <CheckoutForm />
                </Elements>
              )}
            </CardContent>
          </Card>
        </div>
        
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium mb-2">Items ({items.length})</h3>
                  <ul className="space-y-2">
                    {items.map(item => (
                      <li key={item.courseId} className="flex justify-between">
                        <span className="text-slate-600 text-sm">
                          {item.course?.title || `Course #${item.courseId}`} x {item.quantity}
                        </span>
                        <span className="font-medium text-sm">
                          ${item.course?.price ? (item.course.price * item.quantity).toFixed(2) : 'N/A'}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
                <Separator />
                <div className="flex justify-between">
                  <span className="text-slate-600">Subtotal</span>
                  <span className="font-medium">${totalPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Taxes</span>
                  <span className="font-medium">$0.00</span>
                </div>
                <Separator />
                <div className="flex justify-between">
                  <span className="text-slate-800 font-medium">Total</span>
                  <span className="font-bold text-xl">${totalPrice.toFixed(2)}</span>
                </div>
              </div>
            </CardContent>
            <CardFooter className="bg-slate-50 flex flex-col items-start p-4 space-y-2 rounded-b-lg">
              <div className="flex items-start space-x-2">
                <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                <span className="text-sm text-slate-700">Secure checkout powered by Stripe</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                <span className="text-sm text-slate-700">Immediate access to course content after purchase</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                <span className="text-sm text-slate-700">30-day satisfaction guarantee</span>
              </div>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
