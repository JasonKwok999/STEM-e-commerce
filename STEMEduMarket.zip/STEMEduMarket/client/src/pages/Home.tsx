import { useEffect } from 'react';
import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Course } from '@/types';
import CourseCard from '@/components/CourseCard';
import CategoryCard from '@/components/CategoryCard';
import SearchBar from '@/components/SearchBar';
import { Button } from '@/components/ui/button';

const Home = () => {
  const { data: courses, isLoading, error } = useQuery<Course[]>({
    queryKey: ['/api/courses'],
  });

  // Featured courses are bestsellers or new courses
  const featuredCourses = courses?.filter(course => course.bestseller || course.isNew).slice(0, 4);

  return (
    <>
      {/* Hero Section */}
      <section 
        className="relative bg-slate-900 text-white" 
        style={{ 
          backgroundImage: "url('https://images.unsplash.com/photo-1580582932707-520aed937b7b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=600')", 
          backgroundSize: "cover", 
          backgroundPosition: "center" 
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/90 to-slate-900/60"></div>
        <div className="container mx-auto px-4 py-16 md:py-24 relative z-10">
          <div className="max-w-2xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Discover the World of STEM Education</h1>
            <p className="text-lg md:text-xl text-slate-200 mb-8">
              Explore our award-winning courses designed to inspire the next generation of scientists, technologists, engineers, and mathematicians.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Button asChild size="lg">
                <Link href="/courses">Browse Courses</Link>
              </Button>
              <Button variant="outline" asChild size="lg">
                <Link href="/about">Learn More</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Courses Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-slate-800">Featured Courses</h2>
            <Link href="/courses" className="text-primary hover:text-primary/80 font-medium flex items-center">
              View All <span className="ml-2">→</span>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {isLoading ? (
              // Loading skeleton
              Array(4).fill(0).map((_, i) => (
                <div key={i} className="bg-white rounded-xl shadow-md overflow-hidden border border-slate-200 animate-pulse">
                  <div className="w-full h-48 bg-slate-200"></div>
                  <div className="p-5">
                    <div className="h-4 bg-slate-200 rounded w-1/4 mb-4"></div>
                    <div className="h-6 bg-slate-200 rounded w-3/4 mb-2"></div>
                    <div className="h-4 bg-slate-200 rounded w-full mb-3"></div>
                    <div className="h-4 bg-slate-200 rounded w-1/2 mb-4"></div>
                    <div className="flex justify-between items-center">
                      <div className="h-6 bg-slate-200 rounded w-1/4"></div>
                      <div className="h-8 bg-slate-200 rounded w-1/3"></div>
                    </div>
                  </div>
                </div>
              ))
            ) : error ? (
              <div className="col-span-full text-center py-12">
                <p className="text-red-500">Failed to load courses. Please try again later.</p>
              </div>
            ) : featuredCourses?.length ? (
              featuredCourses.map(course => (
                <CourseCard key={course.id} course={course} />
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <p className="text-slate-500">No featured courses available at the moment.</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-12 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-2xl md:text-3xl font-bold text-slate-800 mb-4">Explore STEM Categories</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Discover courses across all STEM disciplines designed to spark curiosity and build essential skills for the future.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <CategoryCard 
              icon="flask"
              title="Science"
              description="Biology, Chemistry, Physics, and Earth Sciences"
              color="text-secondary-600"
              href="/courses?category=Science"
            />
            
            <CategoryCard 
              icon="laptop"
              title="Technology"
              description="Coding, Cybersecurity, and Digital Literacy"
              color="text-primary-600"
              href="/courses?category=Technology"
            />
            
            <CategoryCard 
              icon="cog"
              title="Engineering"
              description="Robotics, Civil Engineering, and Design"
              color="text-green-600"
              href="/courses?category=Engineering"
            />
            
            <CategoryCard 
              icon="calculator"
              title="Mathematics"
              description="Algebra, Calculus, Statistics, and Applied Math"
              color="text-yellow-600"
              href="/courses?category=Mathematics"
            />
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-slate-900 text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">Why Choose Our STEM Courses</h2>
            <p className="text-slate-300 max-w-3xl mx-auto">
              Our courses are designed by industry experts and educators to provide a rich, engaging learning experience that builds real-world skills.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-slate-800/70 p-6 rounded-xl">
              <div className="w-14 h-14 flex items-center justify-center bg-primary/20 text-primary-400 rounded-full mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-3">Expert Instructors</h3>
              <p className="text-slate-300">Learn from industry professionals and academics with years of experience in their respective STEM fields.</p>
            </div>
            
            <div className="bg-slate-800/70 p-6 rounded-xl">
              <div className="w-14 h-14 flex items-center justify-center bg-secondary/20 text-secondary-400 rounded-full mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-3">Hands-On Learning</h3>
              <p className="text-slate-300">Apply concepts through practical projects and experiments that reinforce learning and build confidence.</p>
            </div>
            
            <div className="bg-slate-800/70 p-6 rounded-xl">
              <div className="w-14 h-14 flex items-center justify-center bg-green-600/20 text-green-400 rounded-full mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-3">Recognized Certification</h3>
              <p className="text-slate-300">Earn certificates upon course completion that can enhance your academic portfolio and resume.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-12 bg-primary-600 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">Stay Updated on New Courses</h2>
            <p className="mb-6">Subscribe to our newsletter to receive updates about new courses, special offers, and STEM education tips.</p>
            <form className="flex flex-col sm:flex-row gap-3 justify-center">
              <input 
                type="email" 
                placeholder="Your email address" 
                className="flex-grow px-4 py-3 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-white"
              />
              <Button variant="secondary" size="lg">
                Subscribe
              </Button>
            </form>
            <p className="mt-4 text-sm text-primary-200">We respect your privacy. Unsubscribe at any time.</p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;
