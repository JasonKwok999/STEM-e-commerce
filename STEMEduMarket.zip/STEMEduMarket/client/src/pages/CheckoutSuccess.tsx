import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from '@/hooks/useAuth';
import { useCartStore } from '@/lib/cart';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader, CheckCircle, ArrowRight } from 'lucide-react';

const CheckoutSuccessPage = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  const { items: cartItems, totalPrice: cartTotal, clearCart } = useCartStore();
  
  useEffect(() => {
    document.title = 'Payment Successful | STEM Academy';
    
    // Process the order automatically
    const processOrder = async () => {
      try {
        // Get payment ID from URL
        const paymentIntentId = new URLSearchParams(window.location.search).get('payment_intent');
        
        if (!paymentIntentId) {
          setLoading(false);
          // No error shown - this is probably a simple visit to the success page
          return;
        }
        
        // Check if payment is already recorded
        const checkRes = await apiRequest("GET", `/api/orders/check-payment/${paymentIntentId}`);
        const orderExists = await checkRes.json();
        
        if (!orderExists.exists) {
          // Create the order in our database
          await apiRequest("POST", "/api/orders", { 
            userId: user ? user.id : 0,
            courses: cartItems,
            totalAmount: cartTotal,
            status: 'completed',
            paymentIntentId: paymentIntentId
          });
          
          // Clear the cart after successful order creation
          clearCart();
          
          toast({
            title: "Order Confirmed",
            description: "Your purchase was successful! You now have access to your courses.",
          });
        }
      } catch (e) {
        console.error("Error processing order:", e);
        // We don't show error to user as they already reached success page
      } finally {
        setLoading(false);
      }
    };
    
    processOrder();
    
    return () => {
      document.title = 'STEM Academy';
    };
  }, [toast, user, cartItems, cartTotal, clearCart]);
  
  if (loading) {
    return (
      <div className="container mx-auto px-4 py-24 flex flex-col items-center justify-center">
        <Loader className="h-12 w-12 animate-spin text-primary mb-4" />
        <h1 className="text-2xl font-bold text-center">Finalizing your order...</h1>
        <p className="text-slate-600 mt-2 text-center max-w-lg">
          Please wait while we complete processing your order.
        </p>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="container mx-auto px-4 py-12">
        <Card className="max-w-xl mx-auto">
          <CardHeader className="text-center">
            <CardTitle className="text-red-600">Order Processing Error</CardTitle>
            <CardDescription>
              We encountered a problem processing your order
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <div className="rounded-full bg-red-100 p-4 inline-flex mb-4">
              <svg className="h-8 w-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"></path>
              </svg>
            </div>
            <p className="text-slate-700 mb-4">{error}</p>
          </CardContent>
          <CardFooter className="flex justify-center">
            <Button onClick={() => navigate('/cart')}>
              Return to Cart
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-12">
      <Card className="max-w-xl mx-auto">
        <CardHeader className="text-center">
          <CardTitle className="text-green-600">
            Payment Successful!
          </CardTitle>
          <CardDescription>
            Thank you for your purchase
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <div className="rounded-full bg-green-100 p-4 inline-flex mb-4">
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
          <p className="text-slate-700 mb-4">
            Your payment was successful! You now have access to your courses.
          </p>
          
          <div className="bg-slate-50 p-4 rounded-lg mb-4">
            <p className="text-sm text-slate-500 mb-2">Order Summary</p>
            <p className="text-sm mb-1">
              <span className="font-medium">Courses purchased:</span> {cartItems.length}
            </p>
            <p className="text-sm">
              <span className="font-medium">Total amount:</span> ${cartTotal.toFixed(2)}
            </p>
          </div>
        </CardContent>
        <CardFooter className="flex justify-center space-x-4">
          <Button onClick={() => navigate('/')} variant="outline">
            Return Home
          </Button>
          <Button onClick={() => navigate('/courses')}>
            Start Learning
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default CheckoutSuccessPage;