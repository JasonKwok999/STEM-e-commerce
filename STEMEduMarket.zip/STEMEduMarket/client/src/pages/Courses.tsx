import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Course } from '@/types';
import CourseCard from '@/components/CourseCard';
import CourseFilter from '@/components/CourseFilter';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Grid, List, Loader } from 'lucide-react';

const Courses = () => {
  const [location] = useLocation();
  const [filters, setFilters] = useState({
    categories: [] as string[],
    priceRange: 'all',
    duration: [] as string[],
    rating: '',
  });
  const [sortBy, setSortBy] = useState('popular');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [currentPage, setCurrentPage] = useState(1);
  const coursesPerPage = 9;

  // Extract search and category from URL
  const urlParams = new URLSearchParams(location.split('?')[1]);
  const searchQuery = urlParams.get('search') || '';
  const categoryParam = urlParams.get('category') || '';

  // Fetch all courses
  const { data: courses, isLoading, error } = useQuery<Course[]>({
    queryKey: ['/api/courses', searchQuery, categoryParam],
    queryFn: async () => {
      let url = '/api/courses';
      const params = new URLSearchParams();
      
      if (searchQuery) {
        params.append('search', searchQuery);
      }
      
      if (categoryParam) {
        params.append('category', categoryParam);
      }
      
      if (params.toString()) {
        url += `?${params.toString()}`;
      }
      
      const res = await fetch(url);
      if (!res.ok) throw new Error('Failed to fetch courses');
      return res.json();
    },
  });

  // Apply filters
  const filteredCourses = courses?.filter(course => {
    // Filter by category
    if (filters.categories.length > 0 && !filters.categories.includes(course.category)) {
      return false;
    }
    
    // Filter by price range
    if (filters.priceRange !== 'all') {
      if (filters.priceRange === 'under50' && course.price >= 50) return false;
      if (filters.priceRange === '50to100' && (course.price < 50 || course.price > 100)) return false;
      if (filters.priceRange === '100to200' && (course.price < 100 || course.price > 200)) return false;
      if (filters.priceRange === 'over200' && course.price <= 200) return false;
    }
    
    // Filter by rating
    if (filters.rating) {
      const minRating = parseInt(filters.rating);
      if (course.rating < minRating) return false;
    }
    
    // Filter by duration
    if (filters.duration.length > 0) {
      const weekMatch = course.duration.match(/(\d+)/);
      if (!weekMatch) return false;
      
      const weeks = parseInt(weekMatch[0]);
      
      if (filters.duration.includes('short') && (weeks < 0 || weeks > 4)) return false;
      if (filters.duration.includes('medium') && (weeks < 5 || weeks > 8)) return false;
      if (filters.duration.includes('long') && (weeks < 9 || weeks > 12)) return false;
      if (filters.duration.includes('extended') && weeks < 12) return false;
    }
    
    return true;
  });

  // Sort courses
  const sortedCourses = filteredCourses ? [...filteredCourses] : [];
  switch (sortBy) {
    case 'popular':
      sortedCourses.sort((a, b) => b.rating - a.rating);
      break;
    case 'newest':
      // In a real app, we'd sort by date added, but for this demo we'll use ID as a proxy
      sortedCourses.sort((a, b) => b.id - a.id);
      break;
    case 'price-low':
      sortedCourses.sort((a, b) => a.price - b.price);
      break;
    case 'price-high':
      sortedCourses.sort((a, b) => b.price - a.price);
      break;
    case 'rating':
      sortedCourses.sort((a, b) => b.rating - a.rating);
      break;
  }

  // Pagination
  const indexOfLastCourse = currentPage * coursesPerPage;
  const indexOfFirstCourse = indexOfLastCourse - coursesPerPage;
  const currentCourses = sortedCourses.slice(indexOfFirstCourse, indexOfLastCourse);
  const totalPages = Math.ceil(sortedCourses.length / coursesPerPage);

  // Get unique categories and their counts
  const categoryCounts = courses?.reduce((acc: {name: string, count: number}[], course) => {
    const existingCategory = acc.find(c => c.name === course.category);
    if (existingCategory) {
      existingCategory.count += 1;
    } else {
      acc.push({ name: course.category, count: 1 });
    }
    return acc;
  }, []) || [];

  // Handle filter changes
  const handleFilterChange = (newFilters: any) => {
    setFilters(newFilters);
    setCurrentPage(1); // Reset to first page when filters change
  };

  // Create pagination component
  const Pagination = () => {
    const range = (start: number, end: number) => {
      return Array.from({ length: end - start + 1 }, (_, i) => start + i);
    };

    return (
      <div className="mt-8 flex justify-center">
        <nav className="inline-flex rounded-md shadow">
          <Button
            variant="outline"
            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
            className="rounded-l-md"
          >
            Previous
          </Button>
          
          {range(1, totalPages).map((page) => (
            <Button
              key={page}
              variant={currentPage === page ? 'default' : 'outline'}
              onClick={() => setCurrentPage(page)}
            >
              {page}
            </Button>
          ))}
          
          <Button
            variant="outline"
            onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
            className="rounded-r-md"
          >
            Next
          </Button>
        </nav>
      </div>
    );
  };

  return (
    <section id="courses" className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h1 className="text-2xl md:text-3xl font-bold text-slate-800 mb-8">
          {searchQuery 
            ? `Search Results for "${searchQuery}"` 
            : categoryParam 
              ? `${categoryParam} Courses`
              : 'All Courses'
          }
        </h1>
        
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="lg:w-1/4">
            <CourseFilter 
              categories={categoryCounts}
              onFilterChange={handleFilterChange}
            />
          </div>
          
          {/* Course Grid */}
          <div className="lg:w-3/4">
            {/* Sort & View Options */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
              <div className="flex items-center">
                <span className="text-slate-600 mr-2">Sort by:</span>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="popular">Most Popular</SelectItem>
                    <SelectItem value="newest">Newest</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="rating">Rating</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center space-x-2">
                <Button 
                  variant={viewMode === 'grid' ? 'default' : 'secondary'} 
                  size="icon"
                  onClick={() => setViewMode('grid')}
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button 
                  variant={viewMode === 'list' ? 'default' : 'secondary'} 
                  size="icon"
                  onClick={() => setViewMode('list')}
                >
                  <List className="h-4 w-4" />
                </Button>
                <span className="text-slate-600 ml-4">
                  Showing {indexOfFirstCourse + 1}-{Math.min(indexOfLastCourse, sortedCourses.length)} of {sortedCourses.length} courses
                </span>
              </div>
            </div>
            
            {/* Courses Grid */}
            {isLoading ? (
              <div className="flex justify-center items-center py-20">
                <Loader className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : error ? (
              <div className="text-center py-12">
                <p className="text-red-500">Failed to load courses. Please try again later.</p>
              </div>
            ) : currentCourses.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-xl shadow-sm border border-slate-200">
                <h3 className="text-lg font-medium">No courses found</h3>
                <p className="text-slate-500 mt-2">Try adjusting your filters or search terms</p>
              </div>
            ) : (
              <div className={viewMode === 'grid' 
                ? "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6" 
                : "space-y-6"
              }>
                {currentCourses.map((course) => (
                  <CourseCard key={course.id} course={course} />
                ))}
              </div>
            )}
            
            {/* Pagination */}
            {!isLoading && totalPages > 1 && <Pagination />}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Courses;
