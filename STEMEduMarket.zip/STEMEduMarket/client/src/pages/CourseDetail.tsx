import { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useRoute, Link } from 'wouter';
import { Course } from '@/types';
import { useCartStore } from '@/lib/cart';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { 
  Card, 
  CardContent, 
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Clock, 
  User, 
  Star, 
  CheckCircle, 
  ChevronLeft,
  Loader
} from 'lucide-react';

const CourseDetail = () => {
  const [match, params] = useRoute('/courses/:id');
  const courseId = params?.id ? parseInt(params.id) : null;
  
  const { addItem } = useCartStore();
  const { toast } = useToast();

  const { data: course, isLoading, error } = useQuery<Course>({
    queryKey: [`/api/courses/${courseId}`],
    enabled: !!courseId,
  });

  // Set page title
  useEffect(() => {
    if (course) {
      document.title = `${course.title} | STEM Academy`;
    }
    return () => {
      document.title = 'STEM Academy';
    };
  }, [course]);

  const handleAddToCart = () => {
    if (course) {
      addItem(course);
      toast({
        title: "Added to cart",
        description: `${course.title} has been added to your cart.`,
      });
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center">
        <Loader className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !course) {
    return (
      <div className="container mx-auto px-4 py-12">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <h2 className="text-xl font-bold text-red-500 mb-2">Error Loading Course</h2>
              <p className="text-slate-600 mb-4">
                We couldn't load the course details. Please try again later.
              </p>
              <Button asChild>
                <Link href="/courses">Return to Courses</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <Link href="/courses" className="inline-flex items-center text-primary hover:underline mb-6">
        <ChevronLeft className="mr-1 h-4 w-4" /> Back to Courses
      </Link>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <img 
            src={course.image} 
            alt={course.title}
            className="w-full h-96 object-cover rounded-xl mb-6" 
          />
          
          <div className="bg-white rounded-xl shadow-md border border-slate-200 p-8 mb-8">
            <h1 className="text-3xl font-bold text-slate-800 mb-4">{course.title}</h1>
            
            <div className="flex flex-wrap items-center gap-4 mb-6">
              <Badge variant="secondary" className="px-3 py-1">
                {course.category}
              </Badge>
              
              <div className="flex items-center text-yellow-500">
                {Array(5).fill(0).map((_, i) => (
                  <Star 
                    key={i} 
                    className={`h-5 w-5 ${i < Math.floor(course.rating) ? 'fill-yellow-400' : 'fill-slate-200'}`} 
                  />
                ))}
                <span className="ml-2 text-slate-700">{course.rating.toFixed(1)}</span>
              </div>
              
              <div className="flex items-center text-slate-600">
                <Clock className="mr-1 h-4 w-4" /> {course.duration}
              </div>
              
              <div className="flex items-center text-slate-600">
                <User className="mr-1 h-4 w-4" /> {course.instructor}
              </div>
            </div>
            
            <div className="prose max-w-none mb-8">
              <h2 className="text-xl font-semibold mb-4">Course Description</h2>
              <p className="text-slate-600">{course.description}</p>
              
              <p className="mt-4 text-slate-600">
                This comprehensive course is designed to provide students with a solid foundation in {course.category.toLowerCase()} principles and practical skills. Through a series of engaging lectures, hands-on projects, and interactive assessments, you'll develop the knowledge and confidence to excel in this field.
              </p>
            </div>
            
            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-4">What You'll Learn</h2>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <li className="flex items-center text-slate-600">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span>Fundamental principles of {course.category}</span>
                </li>
                <li className="flex items-center text-slate-600">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span>Hands-on laboratory techniques</span>
                </li>
                <li className="flex items-center text-slate-600">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span>Problem-solving strategies</span>
                </li>
                <li className="flex items-center text-slate-600">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span>Real-world applications</span>
                </li>
                <li className="flex items-center text-slate-600">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span>Industry-standard methodologies</span>
                </li>
                <li className="flex items-center text-slate-600">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span>Critical thinking and analysis</span>
                </li>
              </ul>
            </div>
            
            <div>
              <h2 className="text-xl font-semibold mb-4">About the Instructor</h2>
              <div className="flex items-start space-x-4">
                <div className="w-16 h-16 rounded-full bg-slate-200 flex items-center justify-center text-slate-500">
                  {course.instructor.split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <h3 className="font-semibold text-slate-800">{course.instructor}</h3>
                  <p className="text-slate-600 mt-1">
                    Expert in {course.category} with over 10 years of teaching experience. Passionate about making complex concepts accessible to students of all levels.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div>
          <Card className="sticky top-24">
            <CardHeader>
              <CardTitle className="text-2xl font-bold">${course.price.toFixed(2)}</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 mb-6">
                <li className="flex items-center text-slate-600">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span>{course.duration} of content</span>
                </li>
                <li className="flex items-center text-slate-600">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span>Access on all devices</span>
                </li>
                <li className="flex items-center text-slate-600">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span>Certificate of completion</span>
                </li>
                <li className="flex items-center text-slate-600">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span>Lifetime access</span>
                </li>
                <li className="flex items-center text-slate-600">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span>Project materials included</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter className="flex flex-col gap-4">
              <Button className="w-full" size="lg" onClick={handleAddToCart}>
                Add to Cart
              </Button>
              <Button variant="outline" className="w-full" size="lg" asChild>
                <Link href="/checkout">Buy Now</Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default CourseDetail;
