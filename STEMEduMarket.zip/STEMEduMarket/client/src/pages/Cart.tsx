import { useEffect } from 'react';
import { Link } from 'wouter';
import { useCartStore } from '@/lib/cart';
import { useAuth } from '@/hooks/useAuth';
import { useQuery } from '@tanstack/react-query';
import { Course } from '@/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Trash, ChevronLeft, ChevronRight, ShoppingCart } from 'lucide-react';

const Cart = () => {
  const { items, totalPrice, removeItem, updateQuantity, clearCart } = useCartStore();
  const { user } = useAuth();

  // Load course details for each item in the cart
  const { data: courses } = useQuery({
    queryKey: ['/api/courses'],
    enabled: items.length > 0,
  });

  // Merge cart items with course details
  const cartItemsWithDetails = items.map(item => {
    const course = courses?.find((c: Course) => c.id === item.courseId) || item.course;
    return {
      ...item,
      course
    };
  });

  useEffect(() => {
    document.title = 'Shopping Cart | STEM Academy';
    return () => {
      document.title = 'STEM Academy';
    };
  }, []);

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-slate-800 mb-8">Shopping Cart</h1>
      
      {cartItemsWithDetails.length === 0 ? (
        <Card>
          <CardContent className="pt-12 pb-16 flex flex-col items-center justify-center">
            <div className="w-24 h-24 rounded-full bg-slate-100 flex items-center justify-center mb-6">
              <ShoppingCart className="h-12 w-12 text-slate-400" />
            </div>
            <h2 className="text-2xl font-semibold text-slate-800 mb-2">Your cart is empty</h2>
            <p className="text-slate-500 mb-6 text-center max-w-md">
              Looks like you haven't added any courses to your cart yet. Browse our courses to find something you'll love!
            </p>
            <Button asChild size="lg">
              <Link href="/courses">Browse Courses</Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Course Items ({items.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="divide-y">
                  {cartItemsWithDetails.map(item => (
                    <li key={item.courseId} className="py-6 flex flex-col sm:flex-row gap-4">
                      {item.course?.image && (
                        <div className="flex-shrink-0">
                          <img 
                            src={item.course.image} 
                            alt={item.course.title} 
                            className="w-24 h-24 object-cover rounded-md"
                          />
                        </div>
                      )}
                      <div className="flex-grow">
                        <h3 className="font-semibold text-lg text-slate-800">
                          {item.course?.title || `Course #${item.courseId}`}
                        </h3>
                        <p className="text-slate-500 text-sm">
                          Instructor: {item.course?.instructor || 'Unknown'}
                        </p>
                        {item.course?.duration && (
                          <p className="text-slate-500 text-sm">
                            Duration: {item.course.duration}
                          </p>
                        )}
                      </div>
                      <div className="flex flex-col sm:items-end gap-2">
                        <p className="font-bold text-lg text-slate-800">
                          ${item.course?.price ? (item.course.price * item.quantity).toFixed(2) : 'N/A'}
                        </p>
                        <div className="flex items-center border rounded-md">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8" 
                            onClick={() => updateQuantity(item.courseId, item.quantity - 1)}
                            disabled={item.quantity <= 1}
                          >
                            <ChevronLeft className="h-4 w-4" />
                          </Button>
                          <span className="w-8 text-center">{item.quantity}</span>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8" 
                            onClick={() => updateQuantity(item.courseId, item.quantity + 1)}
                          >
                            <ChevronRight className="h-4 w-4" />
                          </Button>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-red-500 hover:text-red-700 p-0 h-auto" 
                          onClick={() => removeItem(item.courseId)}
                        >
                          <Trash className="h-4 w-4 mr-1" /> Remove
                        </Button>
                      </div>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" asChild>
                  <Link href="/courses">Continue Shopping</Link>
                </Button>
                <Button variant="destructive" onClick={clearCart}>
                  Clear Cart
                </Button>
              </CardFooter>
            </Card>
          </div>
          
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Subtotal</span>
                    <span className="font-medium">${totalPrice.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Discount</span>
                    <span className="font-medium">$0.00</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-slate-800 font-medium">Total</span>
                    <span className="font-bold text-xl">${totalPrice.toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full" size="lg" asChild>
                  <Link href={user ? "/checkout" : "/login?redirect=checkout"}>
                    Proceed to Checkout
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
};

export default Cart;
