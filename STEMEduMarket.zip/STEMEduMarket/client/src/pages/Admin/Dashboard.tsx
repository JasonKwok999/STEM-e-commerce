import { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Analytics, Course, Order } from '@/types';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import {
  DollarSign,
  BookOpen,
  Users,
  TrendingUp
} from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';

const AdminDashboard = () => {
  const { data: analytics, isLoading, error } = useQuery<Analytics>({
    queryKey: ['/api/admin/analytics'],
  });

  useEffect(() => {
    document.title = 'Admin Dashboard | STEM Academy';
    return () => {
      document.title = 'STEM Academy';
    };
  }, []);

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    }).format(date);
  };

  // Transform course data for the chart
  const chartData = analytics?.popularCourses.map(course => ({
    name: course.title.length > 20 ? course.title.substring(0, 20) + '...' : course.title,
    sales: course.rating * 20 // Using rating as a proxy for sales in this demo
  }));

  // Dashboard cards with summary data
  const DashboardCards = () => (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
          <DollarSign className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <Skeleton className="h-8 w-28" />
          ) : (
            <>
              <div className="text-2xl font-bold">${analytics?.totalSales.toFixed(2) || '0.00'}</div>
              <p className="text-xs text-muted-foreground">+12% from last month</p>
            </>
          )}
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Active Courses</CardTitle>
          <BookOpen className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <Skeleton className="h-8 w-16" />
          ) : (
            <>
              <div className="text-2xl font-bold">{analytics?.totalCourses || 0}</div>
              <p className="text-xs text-muted-foreground">+3 new this month</p>
            </>
          )}
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Students</CardTitle>
          <Users className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <Skeleton className="h-8 w-20" />
          ) : (
            <>
              <div className="text-2xl font-bold">1,248</div>
              <p className="text-xs text-muted-foreground">+8% from last month</p>
            </>
          )}
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
          <TrendingUp className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <Skeleton className="h-8 w-16" />
          ) : (
            <>
              <div className="text-2xl font-bold">24.3%</div>
              <p className="text-xs text-muted-foreground">+5% from last month</p>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );

  // Recent transactions table
  const RecentTransactions = () => (
    <Card className="col-span-1 md:col-span-2">
      <CardHeader>
        <CardTitle>Recent Transactions</CardTitle>
        <CardDescription>Recent course purchases by students</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-2">
            {[...Array(3)].map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        ) : error ? (
          <div className="text-center py-6 text-red-500">Error loading transactions</div>
        ) : analytics?.recentOrders && analytics.recentOrders.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order ID</TableHead>
                <TableHead>User ID</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {analytics.recentOrders.map((order: Order) => (
                <TableRow key={order.id}>
                  <TableCell className="font-medium">#{order.id}</TableCell>
                  <TableCell>{order.userId}</TableCell>
                  <TableCell>${order.totalAmount.toFixed(2)}</TableCell>
                  <TableCell>{formatDate(order.createdAt.toString())}</TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      order.status === 'completed' ? 'bg-green-100 text-green-800' : 
                      order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                      'bg-red-100 text-red-800'
                    }`}>
                      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <div className="text-center py-6 text-slate-500">No recent transactions</div>
        )}
        <div className="mt-4 flex justify-end">
          <Button variant="outline" asChild>
            <Link href="/admin/orders">View all</Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  // Course statistics chart
  const CourseStatistics = () => (
    <Card className="col-span-1 md:col-span-2">
      <CardHeader>
        <CardTitle>Course Statistics</CardTitle>
        <CardDescription>Course popularity and sales performance</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <Skeleton className="h-64 w-full" />
        ) : error ? (
          <div className="text-center py-12 text-red-500">Error loading course statistics</div>
        ) : chartData ? (
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="sales" fill="#3B82F6" />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <div className="text-center py-12 text-slate-500">No course data available</div>
        )}
      </CardContent>
    </Card>
  );

  // Popular courses
  const PopularCourses = () => (
    <Card>
      <CardHeader>
        <CardTitle>Popular Courses</CardTitle>
        <CardDescription>Top-performing courses by enrollment</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-2">
            {[...Array(3)].map((_, i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </div>
        ) : error ? (
          <div className="text-center py-6 text-red-500">Error loading courses</div>
        ) : analytics?.popularCourses && analytics.popularCourses.length > 0 ? (
          <ul className="space-y-4">
            {analytics.popularCourses.slice(0, 5).map((course: Course) => (
              <li key={course.id} className="flex items-center space-x-3">
                <div className="flex-shrink-0 w-12 h-12 rounded overflow-hidden">
                  <img 
                    src={course.image} 
                    alt={course.title} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-grow min-w-0">
                  <h4 className="text-sm font-medium text-slate-800 truncate">{course.title}</h4>
                  <p className="text-xs text-slate-500">{course.category}</p>
                </div>
                <div className="flex items-center text-yellow-500">
                  <span className="text-sm font-medium mr-1">{course.rating.toFixed(1)}</span>
                  <svg 
                    width="16" 
                    height="16" 
                    viewBox="0 0 24 24" 
                    fill="currentColor"
                  >
                    <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                  </svg>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <div className="text-center py-6 text-slate-500">No courses available</div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
        <Button asChild>
          <Link href="/admin/courses/new">Add New Course</Link>
        </Button>
      </div>
      
      <DashboardCards />
      
      <div className="grid gap-6 md:grid-cols-2">
        <RecentTransactions />
        <CourseStatistics />
      </div>
      
      <div className="grid gap-6 md:grid-cols-2">
        <PopularCourses />
      </div>
    </div>
  );
};

export default AdminDashboard;
