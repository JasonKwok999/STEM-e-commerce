export interface Course {
  id: number;
  title: string;
  description: string;
  price: number;
  image: string;
  category: string;
  duration: string;
  instructor: string;
  rating: number;
  bestseller?: boolean;
  isNew?: boolean;
}

export interface User {
  id: number;
  username: string;
  email?: string;
  isAdmin: boolean;
}

export interface CartItem {
  courseId: number;
  quantity: number;
  course?: Course;
}

export interface Cart {
  id: number;
  userId: number;
  courses: CartItem[];
  createdAt: Date;
}

export interface Order {
  id: number;
  userId: number;
  courses: CartItem[];
  totalAmount: number;
  status: string;
  paymentIntentId?: string;
  createdAt: Date;
}

export interface Analytics {
  totalSales: number;
  totalCourses: number;
  popularCourses: Course[];
  recentOrders: Order[];
}
