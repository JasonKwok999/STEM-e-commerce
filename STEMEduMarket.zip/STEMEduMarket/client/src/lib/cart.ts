import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Course, CartItem } from '@/types';
import { apiRequest } from '@/lib/queryClient';

interface CartStore {
  items: CartItem[];
  totalItems: number;
  totalPrice: number;
  addItem: (course: Course) => void;
  removeItem: (courseId: number) => void;
  updateQuantity: (courseId: number, quantity: number) => void;
  clearCart: () => void;
  syncWithServer: (userId: number) => Promise<void>;
}

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      totalItems: 0,
      totalPrice: 0,
      
      addItem: (course: Course) => {
        const items = [...get().items];
        const existingItem = items.find(item => item.courseId === course.id);
        
        if (existingItem) {
          existingItem.quantity += 1;
        } else {
          items.push({
            courseId: course.id,
            quantity: 1,
            course
          });
        }
        
        set({
          items,
          totalItems: items.reduce((sum, item) => sum + item.quantity, 0),
          totalPrice: items.reduce((sum, item) => sum + (item.course?.price || 0) * item.quantity, 0)
        });
      },
      
      removeItem: (courseId: number) => {
        const items = get().items.filter(item => item.courseId !== courseId);
        
        set({
          items,
          totalItems: items.reduce((sum, item) => sum + item.quantity, 0),
          totalPrice: items.reduce((sum, item) => sum + (item.course?.price || 0) * item.quantity, 0)
        });
      },
      
      updateQuantity: (courseId: number, quantity: number) => {
        if (quantity <= 0) {
          return get().removeItem(courseId);
        }
        
        const items = [...get().items];
        const item = items.find(item => item.courseId === courseId);
        
        if (item) {
          item.quantity = quantity;
          
          set({
            items,
            totalItems: items.reduce((sum, item) => sum + item.quantity, 0),
            totalPrice: items.reduce((sum, item) => sum + (item.course?.price || 0) * item.quantity, 0)
          });
        }
      },
      
      clearCart: () => {
        set({
          items: [],
          totalItems: 0,
          totalPrice: 0
        });
      },
      
      syncWithServer: async (userId: number) => {
        try {
          const items = get().items;
          const courseIds = items.map(item => ({
            courseId: item.courseId,
            quantity: item.quantity
          }));
          
          await apiRequest('POST', '/api/cart', {
            userId,
            courses: courseIds
          });
        } catch (error) {
          console.error('Error syncing cart with server:', error);
          throw error;
        }
      }
    }),
    {
      name: 'stem-academy-cart'
    }
  )
);
