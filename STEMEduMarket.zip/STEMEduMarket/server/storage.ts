import { users, type User, type InsertUser, courses, type Course, type InsertCourse, carts, type Cart, type InsertCart, orders, type Order, type InsertOrder, CartItem } from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User>;
  
  // Course methods
  getAllCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  getCoursesByCategory(category: string): Promise<Course[]>;
  searchCourses(query: string): Promise<Course[]>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: number, course: Partial<InsertCourse>): Promise<Course>;
  deleteCourse(id: number): Promise<boolean>;
  
  // Cart methods
  getCart(userId: number): Promise<Cart | undefined>;
  createCart(cart: InsertCart): Promise<Cart>;
  updateCart(id: number, cart: Partial<InsertCart>): Promise<Cart>;
  deleteCart(id: number): Promise<boolean>;
  
  // Order methods
  createOrder(order: InsertOrder): Promise<Order>;
  getOrdersByUser(userId: number): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;
  getAllOrders(): Promise<Order[]>;
  updateOrder(id: number, order: Partial<InsertOrder>): Promise<Order>;
  
  // Analytics methods
  getTotalSales(): Promise<number>;
  getPopularCourses(limit: number): Promise<Course[]>;
  getRecentOrders(limit: number): Promise<Order[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private courses: Map<number, Course>;
  private carts: Map<number, Cart>;
  private orders: Map<number, Order>;
  private userIdCounter: number;
  private courseIdCounter: number;
  private cartIdCounter: number;
  private orderIdCounter: number;

  constructor() {
    this.users = new Map();
    this.courses = new Map();
    this.carts = new Map();
    this.orders = new Map();
    this.userIdCounter = 1;
    this.courseIdCounter = 1;
    this.cartIdCounter = 1;
    this.orderIdCounter = 1;
    
    // Add some initial courses
    this.initializeCourses();
  }

  private initializeCourses() {
    const coursesData: InsertCourse[] = [
      {
        title: "Introduction to Robotics",
        description: "Learn the fundamentals of robotics with hands-on projects using Arduino.",
        price: 89.99,
        image: "https://pixabay.com/get/ge10d0fed64448dc1c2e28c1a16e989c9186f0bdaf488f38d92f87e74a0347b7e0849503a3910c6106975c18cbc5ed02031752a76a8e671d86a479a6c221e93fa_1280.jpg",
        category: "Robotics",
        duration: "8 weeks",
        instructor: "Dr. Sarah Chen",
        bestseller: true,
        isNew: false
      },
      {
        title: "Advanced Biology for Teens",
        description: "Explore advanced biological concepts through engaging experiments.",
        price: 74.99,
        image: "https://images.unsplash.com/photo-1581093450021-4a7360e9a6b5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
        category: "Science",
        duration: "6 weeks",
        instructor: "Prof. Michael Lee",
        bestseller: false,
        isNew: true
      },
      {
        title: "Mathematics for Future Engineers",
        description: "Master the math skills essential for engineering careers.",
        price: 99.99,
        image: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
        category: "Mathematics",
        duration: "10 weeks",
        instructor: "Dr. James Wilson",
        bestseller: false,
        isNew: false
      },
      {
        title: "Coding for Kids",
        description: "A fun introduction to programming concepts for children ages 8-12.",
        price: 59.99,
        image: "https://images.unsplash.com/photo-1603354350317-6f7aaa5911c5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
        category: "Technology",
        duration: "4 weeks",
        instructor: "Emma Rodriguez",
        bestseller: true,
        isNew: false
      },
      {
        title: "Chemistry Lab Techniques",
        description: "Master essential laboratory techniques with professional guidance.",
        price: 79.99,
        image: "https://images.unsplash.com/photo-1603126857599-f6e157fa2fe6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
        category: "Science",
        duration: "8 weeks",
        instructor: "Dr. Emily Johnson",
        bestseller: false,
        isNew: false
      },
      {
        title: "Electronics Fundamentals",
        description: "Learn basic electronics concepts and build your own circuits.",
        price: 69.99,
        image: "https://images.unsplash.com/photo-1516110833967-0b5716ca1387?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
        category: "Engineering",
        duration: "6 weeks",
        instructor: "Prof. Robert Chang",
        bestseller: false,
        isNew: false
      },
      {
        title: "Web Development for Teens",
        description: "Create your own websites using HTML, CSS, and JavaScript.",
        price: 89.99,
        image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
        category: "Technology",
        duration: "10 weeks",
        instructor: "Maria Garcia",
        bestseller: false,
        isNew: false
      }
    ];

    coursesData.forEach(course => {
      const id = this.courseIdCounter++;
      this.courses.set(id, { ...course, id, rating: 4.5 + Math.random() * 0.5 });
    });
    
    // Create admin user
    this.users.set(1, {
      id: 1,
      username: "admin",
      password: "admin123",
      email: "admin@stemacademy.com",
      isAdmin: true
    });
    this.userIdCounter = 2;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userUpdate: Partial<InsertUser>): Promise<User> {
    const user = this.users.get(id);
    if (!user) throw new Error(`User with id ${id} not found`);
    
    const updatedUser = { ...user, ...userUpdate };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Course methods
  async getAllCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }

  async getCourse(id: number): Promise<Course | undefined> {
    return this.courses.get(id);
  }

  async getCoursesByCategory(category: string): Promise<Course[]> {
    return Array.from(this.courses.values()).filter(
      (course) => course.category.toLowerCase() === category.toLowerCase()
    );
  }

  async searchCourses(query: string): Promise<Course[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.courses.values()).filter(
      (course) => 
        course.title.toLowerCase().includes(lowercaseQuery) ||
        course.description.toLowerCase().includes(lowercaseQuery) ||
        course.instructor.toLowerCase().includes(lowercaseQuery) ||
        course.category.toLowerCase().includes(lowercaseQuery)
    );
  }

  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const id = this.courseIdCounter++;
    const course: Course = { ...insertCourse, id, rating: 0 };
    this.courses.set(id, course);
    return course;
  }

  async updateCourse(id: number, courseUpdate: Partial<InsertCourse>): Promise<Course> {
    const course = this.courses.get(id);
    if (!course) throw new Error(`Course with id ${id} not found`);
    
    const updatedCourse = { ...course, ...courseUpdate };
    this.courses.set(id, updatedCourse);
    return updatedCourse;
  }

  async deleteCourse(id: number): Promise<boolean> {
    return this.courses.delete(id);
  }

  // Cart methods
  async getCart(userId: number): Promise<Cart | undefined> {
    return Array.from(this.carts.values()).find(
      (cart) => cart.userId === userId
    );
  }

  async createCart(insertCart: InsertCart): Promise<Cart> {
    const id = this.cartIdCounter++;
    const cart: Cart = { ...insertCart, id, createdAt: new Date() };
    this.carts.set(id, cart);
    return cart;
  }

  async updateCart(id: number, cartUpdate: Partial<InsertCart>): Promise<Cart> {
    const cart = this.carts.get(id);
    if (!cart) throw new Error(`Cart with id ${id} not found`);
    
    const updatedCart = { ...cart, ...cartUpdate };
    this.carts.set(id, updatedCart);
    return updatedCart;
  }

  async deleteCart(id: number): Promise<boolean> {
    return this.carts.delete(id);
  }

  // Order methods
  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = this.orderIdCounter++;
    const order: Order = { ...insertOrder, id, createdAt: new Date() };
    this.orders.set(id, order);
    return order;
  }

  async getOrdersByUser(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(
      (order) => order.userId === userId
    );
  }

  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getAllOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }

  async updateOrder(id: number, orderUpdate: Partial<InsertOrder>): Promise<Order> {
    const order = this.orders.get(id);
    if (!order) throw new Error(`Order with id ${id} not found`);
    
    const updatedOrder = { ...order, ...orderUpdate };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  // Analytics methods
  async getTotalSales(): Promise<number> {
    return Array.from(this.orders.values())
      .filter(order => order.status === 'completed')
      .reduce((sum, order) => sum + order.totalAmount, 0);
  }

  async getPopularCourses(limit: number): Promise<Course[]> {
    // This is a simplified implementation since we don't track actual popularity metrics
    return Array.from(this.courses.values())
      .sort((a, b) => b.rating - a.rating)
      .slice(0, limit);
  }

  async getRecentOrders(limit: number): Promise<Order[]> {
    return Array.from(this.orders.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }
}

export const storage = new MemStorage();
