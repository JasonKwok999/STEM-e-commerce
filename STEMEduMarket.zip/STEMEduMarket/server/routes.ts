import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import Stripe from "stripe";
import { z } from "zod";
import { insertCourseSchema, insertUserSchema } from "@shared/schema";

if (!process.env.STRIPE_SECRET_KEY) {
  console.warn('Missing STRIPE_SECRET_KEY environment variable. Using a dummy key for development.');
}

// @ts-ignore - Using latest API version
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || 'sk_test_dummy', {
  apiVersion: '2023-10-16' as any,
});

// Helper function to authenticate admin
const isAdmin = async (req: Request, res: Response, next: Function) => {
  const userId = req.headers['user-id'];
  
  if (!userId) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  try {
    const user = await storage.getUser(Number(userId));
    if (!user || !user.isAdmin) {
      return res.status(403).json({ message: 'Forbidden: Admin access required' });
    }
    next();
  } catch (error) {
    console.error('Admin authentication error:', error);
    return res.status(500).json({ message: 'Server error during authentication' });
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Course routes
  app.get('/api/courses', async (req, res) => {
    try {
      const category = req.query.category as string;
      const search = req.query.search as string;
      
      let courses;
      
      if (search) {
        courses = await storage.searchCourses(search);
      } else if (category) {
        courses = await storage.getCoursesByCategory(category);
      } else {
        courses = await storage.getAllCourses();
      }
      
      res.json(courses);
    } catch (error) {
      console.error('Error fetching courses:', error);
      res.status(500).json({ message: 'Failed to fetch courses' });
    }
  });

  app.get('/api/courses/:id', async (req, res) => {
    try {
      const course = await storage.getCourse(Number(req.params.id));
      
      if (!course) {
        return res.status(404).json({ message: 'Course not found' });
      }
      
      res.json(course);
    } catch (error) {
      console.error('Error fetching course:', error);
      res.status(500).json({ message: 'Failed to fetch course' });
    }
  });

  // Admin course management routes
  app.post('/api/courses', isAdmin, async (req, res) => {
    try {
      const courseData = insertCourseSchema.parse(req.body);
      const course = await storage.createCourse(courseData);
      res.status(201).json(course);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid course data', errors: error.errors });
      }
      console.error('Error creating course:', error);
      res.status(500).json({ message: 'Failed to create course' });
    }
  });

  app.put('/api/courses/:id', isAdmin, async (req, res) => {
    try {
      const courseData = insertCourseSchema.partial().parse(req.body);
      const course = await storage.updateCourse(Number(req.params.id), courseData);
      res.json(course);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid course data', errors: error.errors });
      }
      console.error('Error updating course:', error);
      res.status(500).json({ message: 'Failed to update course' });
    }
  });

  app.delete('/api/courses/:id', isAdmin, async (req, res) => {
    try {
      const success = await storage.deleteCourse(Number(req.params.id));
      
      if (!success) {
        return res.status(404).json({ message: 'Course not found' });
      }
      
      res.status(204).end();
    } catch (error) {
      console.error('Error deleting course:', error);
      res.status(500).json({ message: 'Failed to delete course' });
    }
  });

  // User routes
  app.post('/api/users', async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid user data', errors: error.errors });
      }
      console.error('Error creating user:', error);
      res.status(500).json({ message: 'Failed to create user' });
    }
  });

  app.post('/api/login', async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: 'Username and password are required' });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      
      res.json({ 
        id: user.id,
        username: user.username,
        email: user.email,
        isAdmin: user.isAdmin
      });
    } catch (error) {
      console.error('Error during login:', error);
      res.status(500).json({ message: 'Login failed' });
    }
  });

  // Cart routes
  app.get('/api/cart/:userId', async (req, res) => {
    try {
      const cart = await storage.getCart(Number(req.params.userId));
      
      if (!cart) {
        return res.json({ items: [] });
      }
      
      res.json(cart);
    } catch (error) {
      console.error('Error fetching cart:', error);
      res.status(500).json({ message: 'Failed to fetch cart' });
    }
  });

  app.post('/api/cart', async (req, res) => {
    try {
      const { userId, courses } = req.body;
      
      if (!userId || !courses) {
        return res.status(400).json({ message: 'User ID and courses are required' });
      }
      
      let cart = await storage.getCart(userId);
      
      if (cart) {
        cart = await storage.updateCart(cart.id, { courses });
      } else {
        cart = await storage.createCart({ userId, courses });
      }
      
      res.status(201).json(cart);
    } catch (error) {
      console.error('Error updating cart:', error);
      res.status(500).json({ message: 'Failed to update cart' });
    }
  });

  // Payment routes
  app.post('/api/create-payment-intent', async (req, res) => {
    try {
      const { amount, items } = req.body;
      
      if (!amount) {
        return res.status(400).json({ message: 'Amount is required' });
      }
      
      // Get item details if available
      let metadata = {};
      if (items && Array.isArray(items)) {
        // Create metadata for the order to be stored with the PaymentIntent
        const courseIds = items.map(item => item.courseId).join(',');
        const quantities = items.map(item => item.quantity).join(',');
        
        metadata = {
          courseIds,
          quantities,
          orderTime: new Date().toISOString()
        };
      }
      
      // Create a payment intent with the amount and currency
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: 'usd',
        metadata,
        // Use only payment_method_types instead of automatic_payment_methods
        payment_method_types: ['card'],
      });
      
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      console.error('Error creating payment intent:', error);
      res.status(500).json({ message: `Error creating payment intent: ${error.message}` });
    }
  });

  // Order routes
  app.post('/api/orders', async (req, res) => {
    try {
      const { userId, courses, totalAmount, paymentIntentId } = req.body;
      
      if ((!userId && userId !== 0) || !courses || !totalAmount) {
        return res.status(400).json({ message: 'User ID, courses, and total amount are required' });
      }
      
      // Check if we already have an order with this payment intent ID
      if (paymentIntentId) {
        const orders = await storage.getAllOrders();
        const existingOrder = orders.find(order => order.paymentIntentId === paymentIntentId);
        
        if (existingOrder) {
          return res.status(200).json(existingOrder);
        }
      }
      
      const order = await storage.createOrder({
        userId,
        courses,
        totalAmount,
        status: paymentIntentId ? 'completed' : 'pending',
        paymentIntentId
      });
      
      // If payment was successful, clear the user's cart
      if (paymentIntentId) {
        const cart = await storage.getCart(userId);
        if (cart) {
          await storage.updateCart(cart.id, { courses: [] });
        }
      }
      
      res.status(201).json(order);
    } catch (error) {
      console.error('Error creating order:', error);
      res.status(500).json({ message: 'Failed to create order' });
    }
  });
  
  // Check if a payment has already been recorded in our system
  app.get('/api/orders/check-payment/:paymentIntentId', async (req, res) => {
    try {
      const { paymentIntentId } = req.params;
      
      if (!paymentIntentId) {
        return res.status(400).json({ message: 'Payment intent ID is required' });
      }
      
      const orders = await storage.getAllOrders();
      const existingOrder = orders.find(order => order.paymentIntentId === paymentIntentId);
      
      res.json({ exists: !!existingOrder });
    } catch (error) {
      console.error('Error checking payment:', error);
      res.status(500).json({ message: 'Failed to check payment status' });
    }
  });

  app.get('/api/orders/:userId', async (req, res) => {
    try {
      const orders = await storage.getOrdersByUser(Number(req.params.userId));
      res.json(orders);
    } catch (error) {
      console.error('Error fetching orders:', error);
      res.status(500).json({ message: 'Failed to fetch orders' });
    }
  });

  // Admin analytics routes
  app.get('/api/admin/analytics', isAdmin, async (req, res) => {
    try {
      const totalSales = await storage.getTotalSales();
      const popularCourses = await storage.getPopularCourses(5);
      const recentOrders = await storage.getRecentOrders(5);
      const allCourses = await storage.getAllCourses();
      
      res.json({
        totalSales,
        totalCourses: allCourses.length,
        popularCourses,
        recentOrders
      });
    } catch (error) {
      console.error('Error fetching analytics:', error);
      res.status(500).json({ message: 'Failed to fetch analytics' });
    }
  });

  app.get('/api/admin/orders', isAdmin, async (req, res) => {
    try {
      const orders = await storage.getAllOrders();
      res.json(orders);
    } catch (error) {
      console.error('Error fetching all orders:', error);
      res.status(500).json({ message: 'Failed to fetch orders' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
